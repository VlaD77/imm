using System;
using imm.Core;

namespace imm.UI.Behaviours
{
	public sealed class PlayTweenBehaviour:MonoScheduledBehaviour
	{
		public PlayTweenBehaviour ()
		{
		}
	}
}